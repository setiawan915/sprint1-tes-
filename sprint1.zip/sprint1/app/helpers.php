<?php
use App\Models\Province;
use App\Models\City;
use Ixudra\Curl\Facades\Curl;
function appResponse($data,$code='success',$message='success',$status=200){
  $array=[
    'blocked'=>1000,
    'success'=>1001,
  ];
  $res['status']=$status;
  $res['message']=$message;
  $res['code']=$array[$code];
  if($code=='success') $res['data']=$data;
  else $res['data']=(!empty($data->all()))?[$data->all()]:[];
  return response()->json($res);
}

function cparam($request,$array=[])
{
   $message='Missing Parameter (';
   $check=$now=true;
   foreach ($array as $key=>$value) {
      if(empty($request->input($value))) {
        if($now==false) $message.=',';
         $message.=$value;
         $check=false;
         $now=false;
      }
      if($key==count($array)-1) $message.=')';
   }
   if($check==false) return appResponse($request,'blocked',$message);
   return $check;
}

function cekCity($id){
  $city = City::where('id',$id)->count();
  return $city;
}

function cekProvince($id){
  $province = Province::where('id',$id)->count();
  return $province;
}

function fetch()
{
        $key = '0df6d5bf733214af6c6644eb8717c92c';
        //fetch provinces
        $provinces = Curl::to('https://api.rajaongkir.com/starter/province')
        ->withHeader('key: '.$key)
        ->get();
        $provinces = json_decode($provinces, true);
        if(isset($provinces['rajaongkir']['results'])){
            foreach($provinces['rajaongkir']['results'] as $province){
                $cekProvince = cekProvince($province['province_id']);
                if($cekProvince==0){
                    $saveProvince = new Province;
                    $saveProvince->id    = $province['province_id'];
                    $saveProvince->title = $province['province'];
                    $saveProvince->save();
                }
            }
            $countProvince = count($provinces['rajaongkir']['results']);
        }else{
            $countProvince = 0;
        }

        //fetch city
        $cities = Curl::to('https://api.rajaongkir.com/starter/city')
        ->withHeader('key: '.$key)
        ->get();
        $cities = json_decode($cities, true);
        if(isset($cities['rajaongkir']['results'])){
            foreach($cities['rajaongkir']['results'] as $city){
                $cekCity = cekCity($city['city_id']);
                if($cekCity==0){
                    $saveCity = new City;
                    $saveCity->id = $city['city_id'];
                    $saveCity->province_id  = $city['province_id'];
                    $saveCity->postal_code  = $city['postal_code'];
                    $saveCity->type         = $city['type'];
                    $saveCity->title        = $city['city_name'];
                    $saveCity->save();
                }
            }
            $countCity = count($cities['rajaongkir']['results']);
        }else{
            $countCity = 0;
        }
        
        $resp[] = ['countProvince'=> $countProvince, 'countCity'=> $countCity]; 
        return appResponse($resp,'success');
}
