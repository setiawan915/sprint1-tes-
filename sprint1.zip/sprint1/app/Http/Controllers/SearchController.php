<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Province;
use App\Models\City;

class SearchController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    function province(Request $req){
        $checkParam=cparam($req,['id']);
        if($checkParam!==true) return $checkParam;
        $id = $req->id;
        $respProvince = Province::search($id)->get();
        return appResponse($respProvince,'success');
    }

    function city(Request $req){
        $checkParam=cparam($req,['id']);
        if($checkParam!==true) return $checkParam;
        $id = $req->id;
        $resCity = City::search($id)->get();
        return appResponse($resCity,'success');
    }
}
